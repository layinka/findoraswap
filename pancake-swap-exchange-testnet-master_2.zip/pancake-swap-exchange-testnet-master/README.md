# 🥞 Pancake Swap Exchange Testnet

Live at: https://pancakeswap-testnet.netlify.app/

This repo is for developer community to develop and test smart contracts in testnet environment.

Feel free to open issues if you want to fix or improve anything. I will review and update for that.

If it's useful and helps your big projects, don't forget to donate to me :).

BSC wallet: **0xe50A6B93BAF604f2ec09A840cBb455BB325f6d1e**