export default {
  root: null,
  rootMargin: "200px",
  threshold: 0,
};
