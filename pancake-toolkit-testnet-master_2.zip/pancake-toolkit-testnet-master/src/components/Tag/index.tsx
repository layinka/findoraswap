export { default as Tag } from "./Tag";
export type { TagProps, Variant as TagVariant, Scale as TagScale } from "./types";
