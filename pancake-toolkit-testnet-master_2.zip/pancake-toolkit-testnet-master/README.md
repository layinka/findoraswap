# 🥞 Pancake UIkit Testnet

Pancake UIkit is a set of React components and hooks used to build pages on PancakeSwap Exchange Testnet. 

Do not use this repo for live production.
